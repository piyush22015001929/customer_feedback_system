from django.contrib import admin

from .models import Company, Feedback

admin.site.register(Company)
admin.site.register(Feedback)
